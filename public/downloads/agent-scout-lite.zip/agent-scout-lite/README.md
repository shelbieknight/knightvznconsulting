Agent Scout Lite
by Shelbie Knight, KnightVzn (knightvzn.ai)

A free Claude skill that reviews one Claude project and tells you which repeated manual work is worth turning into an agent first.

HOW TO INSTALL
1. In Claude, open Settings, then Capabilities (or Skills).
2. Upload agent-scout-lite.zip as a new skill.
3. Open a chat inside the project you want reviewed and say: "Run Agent Scout Lite."

Claude will ask a few questions first (which client, how far back to look, which apps to check), then read your chats, files and memory and send back up to 5 ranked agent ideas with the evidence for each.

WHAT IT WILL AND WON'T DO
- It only reads. It never sends, edits, deletes or schedules anything.
- It works best in a project with a few weeks of real chats and files.
- It can only read apps you've connected to Claude.

WANT IT TO RUN EVERY MONTH?
The full Agent Scout runs on a schedule, checks the agents you already have, uses independent QA reviewers, and writes the setup prompt for each agent it suggests. Learn more at knightvzn.ai.

License: free for your own use and your own clients. Please don't resell or repackage it.
